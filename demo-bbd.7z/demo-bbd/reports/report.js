$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("src/test/resources/AwesomeFeature.feature");
formatter.feature({
  "name": "AwesomeFeature",
  "description": "\tIn order to avoid silly mistakes\n\tAs a math idiot\n\tI want to be told the sum of two numbers",
  "keyword": "Feature"
});
formatter.scenario({
  "name": "Add two numbers",
  "description": "",
  "keyword": "Scenario"
});
formatter.step({
  "name": "I have entered 50 into calculator",
  "keyword": "Given "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.step({
  "name": "I have entered 70 into the calculator",
  "keyword": "And "
});
formatter.match({
  "location": "StepDefs.i_have_entered_into_the_calculator(int)"
});
formatter.result({
  "status": "skipped"
});
formatter.step({
  "name": "I press add",
  "keyword": "When "
});
formatter.match({
  "location": "StepDefs.i_press_add()"
});
formatter.result({
  "status": "skipped"
});
formatter.step({
  "name": "the result should be 120 on the screen",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefs.the_result_should_be_on_the_screen(int)"
});
formatter.result({
  "status": "skipped"
});
});